function [d] = v_plane_line_intersection(plane_norm, plane_point, line_norm, line_point)
	d = dot((plane_point-line_point), plane_norm)/(dot(line_norm, plane_norm));
end