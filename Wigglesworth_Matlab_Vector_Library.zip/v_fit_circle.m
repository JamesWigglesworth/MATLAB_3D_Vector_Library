function [ center_point, normal, radius, plot_points, points_2D, center_point_2D, circle_points_2D ] = v_fit_circle(points)
    [normal,v,plane_origin] = v_plane_fit(points);
    plane_pose = v_make_pose(plane_origin, [v normal]);
    points_2D = (plane_pose\[points, ones(size(points,1),1)]')';
    Par = v_fit_circle_2D(points_2D(:,1:2));
    center_point_2D = [Par(1:2), 0];
    radius = Par(3);
    center_point = (plane_pose*[center_point_2D, 1]')';
    
    % Reformatting Results
    center_point(4) = [];
    normal = normal';
    points_2D(:,4) = [];
    
    %% Plot Points
    theta = 0:1:360;
    x = radius*cosd(theta)+center_point_2D(1);
    y = radius*sind(theta)+center_point_2D(2);
    circle_points_2D = [x', y', zeros(length(x),1), ones(length(x), 1)];
    plot_points = (plane_pose*circle_points_2D')';
    plot_points = plot_points(:, 1:3);
end

