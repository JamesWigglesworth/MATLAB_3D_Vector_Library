function [distance] = v_dist_point_to_plane(point, plane_norm, plane_point)
		complete_plane = [plane_norm, dot(v_normalize(plane_norm), plane_point)];
        complete_point = [point 1];
        distance = dot(complete_plane, complete_point);
end
