function [result] = v_normalize(vector)
result = vector ./ v_magnitude(vector);
end