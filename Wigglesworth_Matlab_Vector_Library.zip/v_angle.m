function [result] = v_angle(vector_A, vector_B)
    if(size(vector_A, 2) == 2)
        vector_A = [vector_A, 0];
    end
    if(size(vector_B, 2) == 2)
        vector_B = [vector_B, 0];
    end

    if v_are_equal(vector_A, vector_B)
        result =  0;
    else if v_magnitude(vector_A + vector_B) == 0
            result = 180;
        else
            result = atan2d(v_magnitude(cross(vector_A, vector_B)), dot(vector_A, vector_B));
        end
    end
end