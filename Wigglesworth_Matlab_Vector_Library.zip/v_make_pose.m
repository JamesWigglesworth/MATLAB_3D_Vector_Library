function [ pose ] = v_make_pose( position, orientation )
    pose = eye(4);
    try
        position;
    catch
        position = [0 0 0]; % Defaults to the origin
    end
    try
        orientation;
    catch
        orientation = eye(3); % Defaults to align with coordinate system
    end

    orientation_size = size(orientation);
    if (orientation_size(1) == 3 && orientation_size(2) == 3)
        pose(1:3, 1:3) = orientation;
    else
        if (orientation_size(1) == 1 && orientation_size(2) == 3)
            pose(1:3, 1:3) = v_angles_to_DCM(orientation);
        else
            error('orientaion is not formatted correctly')
        end
    end

    pose(1:3, 4) = position';
end