function [ uL2, uR2 ] = v_closest_points_between_two_lines( uL, vL, uR, vR)
    A1 = -vL(1)^2-vL(2)^2-vL(3)^2;
    B1 = vR(1)*vL(1)+vR(2)*vL(2)+vR(3)*vL(3);
    C1 = uR(1)*vL(1)+uR(2)*vL(2)+uR(3)*vL(3);
    D1 = -uL(1)*vL(1)-uL(2)*vL(2)-uL(3)*vL(3);
    
    A2 = -vL(1)*vR(1)-vL(2)*vR(2)-vL(3)*vR(3);
    B2 = vR(1)^2+vR(2)^2+vR(3)^2;
    C2 = uR(1)*vR(1)+uR(2)*vR(2)+uR(3)*vR(3);
    D2 = -uL(1)*vR(1)-uL(2)*vR(2)-uL(3)*vR(3);
    
    A = [A1 B1; A2 B2];
    b = [-C1-D1; -C2-D2];
    res = A\b;
    alpha = res(1);
    beta = res(2);

    uL2 = uL + alpha * vL;
    uR2 = uR + beta * vR;
end