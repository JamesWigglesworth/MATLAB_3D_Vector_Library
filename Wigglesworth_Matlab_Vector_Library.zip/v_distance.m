function [ result ] = v_distance(U1, U2)
    result = v_magnitude(U1-U2);
end

