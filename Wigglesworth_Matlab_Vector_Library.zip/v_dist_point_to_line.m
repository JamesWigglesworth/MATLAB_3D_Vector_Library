function [d] = v_dist_point_to_line(point, line_point_A, line_point_B)
		term1 = point - line_point_A;
    	term2 = point - line_point_B;
    	term3 = line_point_B - line_point_A;
    	d = distance(cross(term1, term2)) / distance(term3);
end

