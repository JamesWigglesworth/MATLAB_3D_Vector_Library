function [ point ] = v_get_point_from_pose( pose )
point = pose(1:3, 4)';
end

