function [guess_angle] = v_signed_angle(vector_A, vector_B, plane)
    cross_product = v_normalize(cross(vector_A, vector_B));
    if ~(v_are_equal(cross_product, plane, 10) || v_are_equal(-cross_product, plane, 10))
        error('Error: input vectors do not lie in plane')
    end

    guess_angle = v_angle(vector_A, vector_B);
    guess_vector = round(v_rotate(vector_A, plane, guess_angle), 3);
    test_vector = round(vector_B, 3);

    if ~v_are_equal(guess_vector, test_vector)
        guess_angle = -guess_angle;
    end
end