function [ equal_state ] = v_are_equal( vector_1, vector_2, decimal_places )
    try
        decimal_places;
    catch
        decimal_places = 14;
    end
    equal_state = false;
    
    v1_size = size(vector_1);
    v2_size = size(vector_2);
    if ~isequal(v1_size, v2_size)
        return
    end
    scale = 10^decimal_places;
    v1_rounded = round(vector_1*scale)/ scale;
    v2_rounded = round(vector_2*scale)/ scale;

    for i = 1:v1_size(1)
        for j = 1:v1_size(2)
            if v1_rounded(i, j) ~= v2_rounded(i, j)
                return
            end
        end
    end
    equal_state = true;
end

