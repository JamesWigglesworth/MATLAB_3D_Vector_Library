function [ result ] = v_magnitude(vector)
    sum = 0;
    for i = 1:length(vector) 
        sum = sum + vector(i) * vector(i);
    end
    result = sqrt(sum);
end

